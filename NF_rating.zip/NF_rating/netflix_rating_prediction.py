"""
Netflix Movie Rating Prediction
================================
Predicts movie ratings using regression techniques with feature engineering.

Dataset: Netflix_Dataset_Movie.csv (Movie_ID, Year, Name)
Since the dataset contains movie metadata only (no explicit ratings column),
we engineer a synthetic rating score using domain-driven heuristics —
mimicking how the Netflix Prize dataset worked (ratings lived in a
separate customer-ratings file). The model then learns from rich
NLP + temporal features extracted from the movie data.

Pipeline:
  1. Data Loading & EDA
  2. Feature Engineering (temporal, NLP, genre-proxy, era-based)
  3. Synthetic Rating Generation (realistic, noise-injected)
  4. Preprocessing (scaling, encoding)
  5. Model Training (Linear Regression, Ridge, Lasso, Random Forest, Gradient Boosting)
  6. Evaluation (RMSE, MAE, R²)
  7. Visualizations & Insights
"""

# ─────────────────────────────────────────────
# 0. Imports
# ─────────────────────────────────────────────
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import re
from collections import Counter

from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import hstack, csr_matrix

# ─────────────────────────────────────────────
# 1. Load Data
# ─────────────────────────────────────────────
print("=" * 60)
print("  NETFLIX MOVIE RATING PREDICTOR")
print("=" * 60)

df = pd.read_csv("Netflix_Dataset_Movie.csv")
print(f"\n✅ Dataset loaded: {df.shape[0]:,} movies × {df.shape[1]} columns")
print(f"   Columns : {df.columns.tolist()}")
print(f"   Year range : {df['Year'].min()} – {df['Year'].max()}")
print(f"   Null values: {df.isnull().sum().sum()}")
print()

# ─────────────────────────────────────────────
# 2. Feature Engineering
# ─────────────────────────────────────────────
print("── Feature Engineering ─────────────────────────")

# ── 2a. Temporal features
df["Decade"] = (df["Year"] // 10) * 10
df["Age"]    = 2005 - df["Year"]          # how old was the movie at Netflix peak

# ── 2b. Name-length features
df["Name_Length"]     = df["Name"].str.len()
df["Word_Count"]      = df["Name"].str.split().str.len()
df["Avg_Word_Len"]    = df["Name_Length"] / (df["Word_Count"] + 1e-6)

# ── 2c. Title-case / formatting signals
df["Has_Number"]      = df["Name"].str.contains(r"\d", regex=True).astype(int)
df["Has_Colon"]       = df["Name"].str.contains(r":", regex=False).astype(int)
df["Has_Apostrophe"]  = df["Name"].str.contains(r"'", regex=False).astype(int)
df["Is_Series"]       = df["Name"].str.contains(
    r"\b(Part|Vol|Volume|Season|Episode|Chapter|II|III|IV|V)\b",
    case=False, regex=True
).astype(int)

# ── 2d. Keyword-based genre proxies  (rough but effective heuristics)
genres = {
    "Action"    : r"\b(action|war|battle|fight|hero|attack|force|mission|command)\b",
    "Comedy"    : r"\b(comedy|funny|laugh|hilarious|fun|silly|crazy|wild)\b",
    "Drama"     : r"\b(drama|life|story|love|heart|soul|passion|journey)\b",
    "Horror"    : r"\b(horror|evil|nightmare|scary|ghost|terror|dark|dead|zombie)\b",
    "Romance"   : r"\b(romance|love|wedding|kiss|desire|affair|heart)\b",
    "Documentary": r"\b(documentary|real|story|history|world|planet|nature|earth|life)\b",
    "Animation" : r"\b(animation|cartoon|adventure|magic|fantasy|dream|world)\b",
    "Thriller"  : r"\b(thriller|suspense|mystery|secret|hidden|killer|danger)\b",
    "Sci_Fi"    : r"\b(space|star|galaxy|future|robot|alien|science|quantum|cyber)\b",
    "Sport"     : r"\b(sport|race|game|championship|tour|olympic|football|soccer|tennis)\b",
}

for genre, pattern in genres.items():
    df[f"Genre_{genre}"] = df["Name"].str.contains(pattern, case=False, regex=True).astype(int)

df["Genre_Count"] = df[[f"Genre_{g}" for g in genres]].sum(axis=1)

# ── 2e. Prestige-era multiplier  (award-friendly decades)
prestige_decade = {1915:3.2, 1920:3.1, 1930:3.3, 1940:3.5, 1950:3.6,
                   1960:3.7, 1970:3.5, 1980:3.4, 1990:3.3, 2000:3.2}
df["Era_Prestige"] = df["Decade"].map(prestige_decade).fillna(3.0)

print(f"   Features engineered: {df.shape[1] - 3} new columns added")
print()

# ─────────────────────────────────────────────
# 3. Synthetic Rating Generation
# ─────────────────────────────────────────────
print("── Synthetic Rating Generation ─────────────────")
"""
We simulate Netflix-style ratings (1–5 scale) using a realistic linear
combination of engineered features + Gaussian noise. This matches how
the Netflix Prize ground-truth worked: ratings were user-given (1–5)
and averaged per movie. Without that file, we reconstruct plausible
mean ratings.
"""

np.random.seed(42)
n = len(df)

base   = 3.0
signal = (
      0.002  * (df["Year"] - 1990)          # newer ≈ slightly higher rated
    - 0.001  * df["Age"]                     # recency bonus
    + 0.05   * df["Genre_Drama"]             # drama gets rated higher
    + 0.08   * df["Genre_Documentary"]       # docs rated high
    - 0.04   * df["Genre_Horror"]            # horror ≈ lower avg
    + 0.06   * df["Genre_Animation"]
    + 0.03   * df["Genre_Comedy"]
    + 0.04   * df["Genre_Romance"]
    + 0.05   * df["Genre_Sci_Fi"]
    + 0.15   * df["Era_Prestige"]            # classic-era premium
    + 0.01   * df["Word_Count"]              # long titles ≈ epic films
    - 0.005  * df["Name_Length"]             # but not too wordy
    + 0.05   * df["Is_Series"]               # sequels/series ≈ established brand
    + np.random.normal(0, 0.45, n)           # noise
)

df["Rating"] = np.clip(base + signal, 1.0, 5.0).round(2)

print(f"   Rating stats  →  mean={df['Rating'].mean():.2f}, "
      f"std={df['Rating'].std():.2f}, "
      f"min={df['Rating'].min():.2f}, max={df['Rating'].max():.2f}")
print()

# ─────────────────────────────────────────────
# 4. Feature Matrix
# ─────────────────────────────────────────────
feature_cols = [
    "Year", "Age", "Decade", "Name_Length", "Word_Count", "Avg_Word_Len",
    "Has_Number", "Has_Colon", "Has_Apostrophe", "Is_Series",
    "Era_Prestige", "Genre_Count",
] + [f"Genre_{g}" for g in genres]

X = df[feature_cols].values
y = df["Rating"].values

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

scaler  = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)

print(f"── Train/Test Split ────────────────────────────")
print(f"   Train: {X_train.shape[0]:,} samples | Test: {X_test.shape[0]:,} samples")
print(f"   Features: {len(feature_cols)}")
print()

# ─────────────────────────────────────────────
# 5. Model Training & Evaluation
# ─────────────────────────────────────────────
print("── Model Training ──────────────────────────────")

models = {
    "Linear Regression"       : LinearRegression(),
    "Ridge (α=1)"             : Ridge(alpha=1.0),
    "Lasso (α=0.01)"          : Lasso(alpha=0.01, max_iter=5000),
    "Random Forest"           : RandomForestRegressor(
                                    n_estimators=200,
                                    max_depth=8,
                                    min_samples_split=5,
                                    random_state=42,
                                    n_jobs=-1),
    "Gradient Boosting"       : GradientBoostingRegressor(
                                    n_estimators=200,
                                    learning_rate=0.08,
                                    max_depth=5,
                                    subsample=0.8,
                                    random_state=42),
}

results = {}
cv = KFold(n_splits=5, shuffle=True, random_state=42)

for name, model in models.items():
    # Fit
    model.fit(X_train_s, y_train)
    y_pred = model.predict(X_test_s)

    # Metrics
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    mae  = mean_absolute_error(y_test, y_pred)
    r2   = r2_score(y_test, y_pred)

    # CV RMSE
    cv_scores = cross_val_score(model, X_train_s, y_train,
                                scoring="neg_root_mean_squared_error", cv=cv)
    cv_rmse = -cv_scores.mean()

    results[name] = {
        "model"  : model,
        "y_pred" : y_pred,
        "RMSE"   : rmse,
        "MAE"    : mae,
        "R²"     : r2,
        "CV_RMSE": cv_rmse,
    }

    print(f"   {name:<28}  RMSE={rmse:.4f}  MAE={mae:.4f}  R²={r2:.4f}  CV-RMSE={cv_rmse:.4f}")

# Best model
best_name = min(results, key=lambda k: results[k]["RMSE"])
best      = results[best_name]
print(f"\n   🏆 Best model: {best_name} (RMSE={best['RMSE']:.4f})")
print()

# ─────────────────────────────────────────────
# 6. Feature Importance (tree models)
# ─────────────────────────────────────────────
rf_model = results["Random Forest"]["model"]
gb_model = results["Gradient Boosting"]["model"]

# ─────────────────────────────────────────────
# 7. Visualisations
# ─────────────────────────────────────────────
print("── Generating visualisations ───────────────────")

palette  = "#E50914"     # Netflix red
bg_color = "#141414"     # Netflix dark
txt_color= "#FFFFFF"
accent   = "#F5F5F1"

plt.rcParams.update({
    "figure.facecolor" : bg_color,
    "axes.facecolor"   : "#1c1c1c",
    "axes.edgecolor"   : "#444444",
    "axes.labelcolor"  : accent,
    "xtick.color"      : accent,
    "ytick.color"      : accent,
    "text.color"       : accent,
    "grid.color"       : "#2a2a2a",
    "grid.linestyle"   : "--",
    "grid.alpha"       : 0.5,
    "font.family"      : "DejaVu Sans",
})

fig = plt.figure(figsize=(22, 28))
fig.suptitle("🎬  Netflix Movie Rating Predictor — ML Report",
             fontsize=20, fontweight="bold", color=palette, y=0.98)

gs = gridspec.GridSpec(4, 3, figure=fig, hspace=0.45, wspace=0.35)

# ── Plot 1: Rating distribution
ax1 = fig.add_subplot(gs[0, 0])
ax1.hist(df["Rating"], bins=40, color=palette, edgecolor="#333", alpha=0.85)
ax1.axvline(df["Rating"].mean(), color="#FFC107", lw=2,
            linestyle="--", label=f"Mean={df['Rating'].mean():.2f}")
ax1.set_title("Rating Distribution", fontweight="bold", color=palette)
ax1.set_xlabel("Rating (1–5)")
ax1.set_ylabel("Count")
ax1.legend()

# ── Plot 2: Movies per decade
ax2 = fig.add_subplot(gs[0, 1])
decade_counts = df["Decade"].value_counts().sort_index()
ax2.bar(decade_counts.index.astype(str), decade_counts.values,
        color=palette, edgecolor="#555", alpha=0.85, width=0.7)
ax2.set_title("Movies by Decade", fontweight="bold", color=palette)
ax2.set_xlabel("Decade")
ax2.set_ylabel("Count")
ax2.tick_params(axis="x", rotation=45)

# ── Plot 3: Avg rating per decade
ax3 = fig.add_subplot(gs[0, 2])
avg_decade = df.groupby("Decade")["Rating"].mean()
ax3.plot(avg_decade.index, avg_decade.values,
         color="#FFC107", marker="o", lw=2)
ax3.fill_between(avg_decade.index, avg_decade.values, alpha=0.15, color="#FFC107")
ax3.set_title("Avg Rating by Decade", fontweight="bold", color=palette)
ax3.set_xlabel("Decade")
ax3.set_ylabel("Avg Rating")

# ── Plot 4: Model comparison — RMSE
ax4 = fig.add_subplot(gs[1, :2])
names  = list(results.keys())
rmses  = [results[n]["RMSE"] for n in names]
colors = [palette if n == best_name else "#555555" for n in names]
bars   = ax4.barh(names, rmses, color=colors, edgecolor="#333", alpha=0.9)
for bar, v in zip(bars, rmses):
    ax4.text(v + 0.002, bar.get_y() + bar.get_height() / 2,
             f"{v:.4f}", va="center", color=accent, fontsize=10)
ax4.set_title("Model Comparison — Test RMSE (lower = better)",
              fontweight="bold", color=palette)
ax4.set_xlabel("RMSE")
ax4.invert_yaxis()

# ── Plot 5: R² scores
ax5 = fig.add_subplot(gs[1, 2])
r2s = [results[n]["R²"] for n in names]
ax5.barh(names, r2s, color="#1DB954", edgecolor="#333", alpha=0.85)
ax5.set_title("R² Score (higher = better)", fontweight="bold", color=palette)
ax5.set_xlabel("R²")
ax5.invert_yaxis()
ax5.set_xlim(0, 1)

# ── Plot 6: Actual vs Predicted (best model)
ax6 = fig.add_subplot(gs[2, 0])
y_pred_best = best["y_pred"]
ax6.scatter(y_test, y_pred_best, color=palette, alpha=0.25, s=6)
lo, hi = y_test.min(), y_test.max()
ax6.plot([lo, hi], [lo, hi], color="#FFC107", lw=1.5, linestyle="--")
ax6.set_title(f"Actual vs Predicted\n({best_name})", fontweight="bold", color=palette)
ax6.set_xlabel("Actual Rating")
ax6.set_ylabel("Predicted Rating")

# ── Plot 7: Residuals
ax7 = fig.add_subplot(gs[2, 1])
residuals = y_test - y_pred_best
ax7.scatter(y_pred_best, residuals, color="#1DB954", alpha=0.2, s=6)
ax7.axhline(0, color="#FFC107", lw=1.5, linestyle="--")
ax7.set_title("Residual Plot", fontweight="bold", color=palette)
ax7.set_xlabel("Predicted Rating")
ax7.set_ylabel("Residual")

# ── Plot 8: Residual histogram
ax8 = fig.add_subplot(gs[2, 2])
ax8.hist(residuals, bins=50, color="#1DB954", edgecolor="#333", alpha=0.85)
ax8.axvline(0, color="#FFC107", lw=2, linestyle="--")
ax8.set_title("Residual Distribution", fontweight="bold", color=palette)
ax8.set_xlabel("Residual")
ax8.set_ylabel("Count")

# ── Plot 9: Feature importance (RF)
ax9 = fig.add_subplot(gs[3, :2])
fi  = rf_model.feature_importances_
fi_df = pd.DataFrame({"Feature": feature_cols, "Importance": fi}) \
          .sort_values("Importance", ascending=True).tail(15)
ax9.barh(fi_df["Feature"], fi_df["Importance"], color=palette, edgecolor="#333", alpha=0.85)
ax9.set_title("Feature Importance — Random Forest (Top 15)",
              fontweight="bold", color=palette)
ax9.set_xlabel("Importance")

# ── Plot 10: CV RMSE comparison
ax10 = fig.add_subplot(gs[3, 2])
cv_rmses = [results[n]["CV_RMSE"] for n in names]
ax10.bar(range(len(names)), cv_rmses,
         color=[palette if n == best_name else "#555555" for n in names],
         edgecolor="#333", alpha=0.9)
ax10.set_xticks(range(len(names)))
ax10.set_xticklabels([n.split()[0] for n in names], rotation=30, ha="right")
ax10.set_title("5-Fold CV RMSE", fontweight="bold", color=palette)
ax10.set_ylabel("RMSE")

plt.savefig("netflix_rating_prediction.png",
            dpi=150, bbox_inches="tight", facecolor=bg_color)
plt.close()
print("   ✅ Saved: netflix_rating_prediction.png")

# ─────────────────────────────────────────────
# 8. Recommendation Engine
# ─────────────────────────────────────────────
print()
print("── Top 10 Predicted Blockbusters ───────────────")

df["Predicted_Rating"] = results["Gradient Boosting"]["model"].predict(
    scaler.transform(df[feature_cols].values)
)

top10 = df.nlargest(10, "Predicted_Rating")[["Name", "Year", "Predicted_Rating"]]
top10.index = range(1, 11)
print(top10.to_string())

# ─────────────────────────────────────────────
# 9. Summary
# ─────────────────────────────────────────────
print()
print("=" * 60)
print("  RESULTS SUMMARY")
print("=" * 60)
print(f"  Dataset      : {len(df):,} movies (1915–2005)")
print(f"  Features     : {len(feature_cols)}")
print(f"  Models tried : {len(models)}")
print()
print(f"  {'Model':<28} {'RMSE':>8} {'MAE':>8} {'R²':>8}")
print(f"  {'-'*52}")
for name in results:
    r = results[name]
    marker = " ★" if name == best_name else "  "
    print(f"  {name:<28} {r['RMSE']:>8.4f} {r['MAE']:>8.4f} {r['R²']:>8.4f}{marker}")
print()
print(f"  🏆 Best model : {best_name}")
print(f"     RMSE={best['RMSE']:.4f}  |  MAE={best['MAE']:.4f}  |  R²={best['R²']:.4f}")
print()
print("  Visualisation saved to: netflix_rating_prediction.png")
print("=" * 60)
