"""
Email Spam Classifier
=====================
Trains Naive Bayes and Logistic Regression classifiers using:
- Real ham emails from easy_ham_2 dataset
- Synthetic spam emails for balanced training
"""

import os
import re
import email
import random
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, roc_curve, accuracy_score
)
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")
random.seed(42)
np.random.seed(42)

HAM_DIR = "/home/claude/data/easy_ham"

# ─────────────────────────────────────────────
# 1. LOAD & PARSE REAL HAM EMAILS
# ─────────────────────────────────────────────

def parse_email(filepath):
    """Extract subject + body text from a raw email file."""
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            raw = f.read()
        msg = email.message_from_string(raw)
        subject = msg.get("Subject", "") or ""
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    body += part.get_payload(decode=True).decode("utf-8", errors="ignore")
        else:
            payload = msg.get_payload(decode=True)
            if payload:
                body = payload.decode("utf-8", errors="ignore")
        return (subject + " " + body).strip()
    except Exception:
        return ""

print("📂 Loading ham emails...")
ham_texts = []
for fname in os.listdir(HAM_DIR):
    path = os.path.join(HAM_DIR, fname)
    text = parse_email(path)
    if len(text) > 50:
        ham_texts.append(text)

print(f"   ✅ Loaded {len(ham_texts)} ham emails")

# ─────────────────────────────────────────────
# 2. GENERATE SYNTHETIC SPAM EMAILS
# ─────────────────────────────────────────────

SPAM_TEMPLATES = [
    "Congratulations! You have won a {prize}! Click here to claim your {prize} now! Limited offer!",
    "FREE {product}! Act now! This is not a scam. Make {amount} per day working from home!",
    "URGENT: Your account has been suspended. Verify your information immediately at http://scam.example.com",
    "Dear winner, You have been selected for our lottery. Send your bank details to claim ${amount}",
    "BUY NOW! Discount {pct}% off on {product}. Best deal ever. Click below. Unsubscribe here.",
    "You are pre-approved for a loan of ${amount}. No credit check. Apply now! Call 1-800-SCAM-NOW",
    "Hot {product} deals! Special offer today only. Make money fast. Free trial. No risk!",
    "ALERT: Suspicious login detected. Confirm password at http://phishing.example.net immediately!",
    "Earn ${amount} weekly from home. No experience needed. Join millions already making money online!",
    "Your {product} order is ready. Pay only shipping. {pct}% off retail. Act before midnight!",
    "Nigerian prince needs help. Deposit $100 receive $10,000. Guaranteed profit. Reply NOW.",
    "Cheap {product} meds online no prescription needed. Best prices. Fast shipping. Order now!",
    "You qualify for FREE insurance. Call us today. No obligation. Save hundreds per month guaranteed!",
    "Unlock your iphone now! Click here for exclusive deals. Limited time offer. Best price!",
    "Meet singles near you tonight! Free registration. No credit card. Join now for FREE!",
]

PRIZES = ["$1,000,000", "a luxury car", "a dream vacation", "an iPhone", "$500 gift card"]
PRODUCTS = ["pills", "watches", "software", "insurance", "loans", "supplements", "phones"]
AMOUNTS = ["5,000", "10,000", "500", "2,000", "50,000"]
PCTS = ["50", "70", "80", "90", "60"]

def generate_spam():
    tmpl = random.choice(SPAM_TEMPLATES)
    return tmpl.format(
        prize=random.choice(PRIZES),
        product=random.choice(PRODUCTS),
        amount=random.choice(AMOUNTS),
        pct=random.choice(PCTS),
    )

n_spam = len(ham_texts)
spam_texts = [generate_spam() for _ in range(n_spam)]
print(f"   ✅ Generated {len(spam_texts)} spam emails")

# ─────────────────────────────────────────────
# 3. BUILD DATAFRAME & PREPROCESS
# ─────────────────────────────────────────────

def clean_text(text):
    """Lowercase, remove URLs, special chars, extra whitespace."""
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", " url ", text)   # replace URLs
    text = re.sub(r"[\w.+-]+@[\w-]+\.[\w.]+", " email ", text)  # replace emails
    text = re.sub(r"\$[\d,]+", " money ", text)         # replace dollar amounts
    text = re.sub(r"[^a-z\s]", " ", text)               # remove non-alpha
    text = re.sub(r"\s+", " ", text).strip()
    return text

texts = ham_texts + spam_texts
labels = [0] * len(ham_texts) + [1] * len(spam_texts)  # 0=ham, 1=spam

df = pd.DataFrame({"text": texts, "label": labels})
df["clean_text"] = df["text"].apply(clean_text)
df["label_name"] = df["label"].map({0: "Ham", 1: "Spam"})

print(f"\n📊 Dataset: {len(df)} emails | Ham: {sum(labels==0 for labels in df.label)} | Spam: {sum(labels==1 for labels in df.label)}")

X = df["clean_text"]
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"   Train: {len(X_train)} | Test: {len(X_test)}")

# ─────────────────────────────────────────────
# 4. DEFINE PIPELINES (BoW + TF-IDF × NB + LR)
# ─────────────────────────────────────────────

pipelines = {
    "NB + BoW": Pipeline([
        ("vec", CountVectorizer(max_features=10000, ngram_range=(1, 2), stop_words="english")),
        ("clf", MultinomialNB(alpha=0.5)),
    ]),
    "NB + TF-IDF": Pipeline([
        ("vec", TfidfVectorizer(max_features=10000, ngram_range=(1, 2), stop_words="english")),
        ("clf", MultinomialNB(alpha=0.5)),
    ]),
    "LR + BoW": Pipeline([
        ("vec", CountVectorizer(max_features=10000, ngram_range=(1, 2), stop_words="english")),
        ("clf", LogisticRegression(max_iter=1000, C=1.0, random_state=42)),
    ]),
    "LR + TF-IDF": Pipeline([
        ("vec", TfidfVectorizer(max_features=10000, ngram_range=(1, 2), stop_words="english")),
        ("clf", LogisticRegression(max_iter=1000, C=1.0, random_state=42)),
    ]),
}

# ─────────────────────────────────────────────
# 5. TRAIN & EVALUATE
# ─────────────────────────────────────────────

results = {}

print("\n🚀 Training models...\n")
for name, pipe in pipelines.items():
    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)
    y_prob = pipe.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_prob)
    cv  = cross_val_score(pipe, X, y, cv=5, scoring="accuracy").mean()

    results[name] = {
        "pipeline": pipe,
        "y_pred": y_pred,
        "y_prob": y_prob,
        "accuracy": acc,
        "auc": auc,
        "cv_accuracy": cv,
        "report": classification_report(y_test, y_pred, target_names=["Ham","Spam"]),
        "cm": confusion_matrix(y_test, y_pred),
    }

    print(f"  {name}")
    print(f"    Accuracy:    {acc:.4f}")
    print(f"    ROC-AUC:     {auc:.4f}")
    print(f"    CV Accuracy: {cv:.4f}")
    print(f"    Classification Report:\n")
    for line in results[name]["report"].split("\n"):
        print(f"      {line}")
    print()

# ─────────────────────────────────────────────
# 6. PLOTS
# ─────────────────────────────────────────────

fig, axes = plt.subplots(2, 3, figsize=(18, 12))
fig.suptitle("Spam Classifier — Model Evaluation Dashboard", fontsize=16, fontweight="bold", y=0.98)

PALETTE = {"NB + BoW": "#4C72B0", "NB + TF-IDF": "#DD8452",
           "LR + BoW": "#55A868", "LR + TF-IDF": "#C44E52"}

# ── (A) Bar chart: Accuracy & AUC comparison ──
ax = axes[0, 0]
model_names = list(results.keys())
accs = [results[m]["accuracy"] for m in model_names]
aucs = [results[m]["auc"]      for m in model_names]
x = np.arange(len(model_names))
bars1 = ax.bar(x - 0.2, accs, 0.35, label="Accuracy", color=[PALETTE[m] for m in model_names], alpha=0.85)
bars2 = ax.bar(x + 0.2, aucs, 0.35, label="ROC-AUC",  color=[PALETTE[m] for m in model_names], alpha=0.45, hatch="//")
ax.set_xticks(x); ax.set_xticklabels(model_names, rotation=15, ha="right")
ax.set_ylim(0.85, 1.01)
ax.set_title("Accuracy vs ROC-AUC by Model")
ax.set_ylabel("Score")
ax.legend()
for bar in bars1: ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.002, f"{bar.get_height():.3f}", ha="center", fontsize=8)
for bar in bars2: ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.002, f"{bar.get_height():.3f}", ha="center", fontsize=8)

# ── (B) ROC curves ──
ax = axes[0, 1]
for name, res in results.items():
    fpr, tpr, _ = roc_curve(y_test, res["y_prob"])
    ax.plot(fpr, tpr, label=f"{name} (AUC={res['auc']:.3f})", color=PALETTE[name], linewidth=2)
ax.plot([0,1],[0,1], "k--", linewidth=1)
ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate")
ax.set_title("ROC Curves"); ax.legend(fontsize=8); ax.grid(alpha=0.3)

# ── (C) Cross-validation scores ──
ax = axes[0, 2]
cv_scores = [results[m]["cv_accuracy"] for m in model_names]
colors = [PALETTE[m] for m in model_names]
bars = ax.barh(model_names, cv_scores, color=colors, alpha=0.85)
ax.set_xlim(0.85, 1.01)
ax.set_title("5-Fold Cross-Validation Accuracy")
ax.set_xlabel("CV Accuracy")
for bar, score in zip(bars, cv_scores):
    ax.text(score + 0.001, bar.get_y() + bar.get_height()/2, f"{score:.4f}", va="center", fontsize=9)

# ── (D-G) Confusion matrices (best 2 models) ──
best_models = sorted(results.items(), key=lambda x: x[1]["auc"], reverse=True)[:2]
for i, (name, res) in enumerate(best_models):
    ax = axes[1, i]
    cm = res["cm"]
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                xticklabels=["Ham","Spam"], yticklabels=["Ham","Spam"],
                linewidths=0.5, cbar=False, annot_kws={"size": 14})
    ax.set_title(f"Confusion Matrix — {name}")
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")

# ── Top TF-IDF features for best model ──
ax = axes[1, 2]
best_name = max(results, key=lambda m: results[m]["auc"])
best_pipe = results[best_name]["pipeline"]
vec = best_pipe.named_steps["vec"]
clf = best_pipe.named_steps["clf"]
feature_names = np.array(vec.get_feature_names_out())

if hasattr(clf, "coef_"):
    coefs = clf.coef_[0]
    top_spam_idx = np.argsort(coefs)[-15:][::-1]
    top_ham_idx  = np.argsort(coefs)[:15]

    top_words = (list(feature_names[top_spam_idx]) + list(feature_names[top_ham_idx]))
    top_coefs = (list(coefs[top_spam_idx]) + list(coefs[top_ham_idx]))
    colors_feat = ["#C44E52"] * 15 + ["#4C72B0"] * 15

    y_pos = np.arange(len(top_words))
    ax.barh(y_pos, top_coefs, color=colors_feat, alpha=0.8)
    ax.set_yticks(y_pos); ax.set_yticklabels(top_words, fontsize=7)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_title(f"Top Features — {best_name}\n(Red=Spam, Blue=Ham)")
    ax.set_xlabel("Coefficient")
else:
    # NB: log probabilities
    log_probs = clf.feature_log_prob_
    spam_score = log_probs[1] - log_probs[0]
    top_spam_idx = np.argsort(spam_score)[-15:][::-1]
    top_ham_idx  = np.argsort(spam_score)[:15]
    top_words = list(feature_names[top_spam_idx]) + list(feature_names[top_ham_idx])
    top_scores = list(spam_score[top_spam_idx]) + list(spam_score[top_ham_idx])
    colors_feat = ["#C44E52"] * 15 + ["#4C72B0"] * 15
    y_pos = np.arange(len(top_words))
    ax.barh(y_pos, top_scores, color=colors_feat, alpha=0.8)
    ax.set_yticks(y_pos); ax.set_yticklabels(top_words, fontsize=7)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_title(f"Top Features — {best_name}\n(Red=Spam, Blue=Ham)")
    ax.set_xlabel("Log-Prob Ratio (Spam - Ham)")

plt.tight_layout()
plt.savefig("/mnt/user-data/outputs/spam_classifier_results.png", dpi=150, bbox_inches="tight")
print("📈 Saved plot to spam_classifier_results.png")

# ─────────────────────────────────────────────
# 7. DEMO PREDICTIONS
# ─────────────────────────────────────────────

best_pipe = results[best_name]["pipeline"]
demo_emails = [
    "Hi John, please find attached the meeting notes from today's project sync. Let me know if you have questions.",
    "CONGRATULATIONS! You won $1,000,000! Click here NOW to claim your prize! Limited time offer!",
    "Your pull request has been approved. CI passed all checks. Ready to merge.",
    "FREE PILLS! No prescription needed! Buy cheap meds online! Best prices! Act now!",
    "Reminder: team standup at 10am tomorrow. Please update your Jira tickets beforehand.",
    "URGENT! Your bank account is suspended! Verify at http://fake-bank.scam.net immediately!",
]

print("\n🔍 Demo Predictions (Best Model: {}):\n".format(best_name))
for email_text in demo_emails:
    pred = best_pipe.predict([clean_text(email_text)])[0]
    prob = best_pipe.predict_proba([clean_text(email_text)])[0][1]
    label = "🚨 SPAM" if pred == 1 else "✅ HAM "
    print(f"  {label} ({prob:.2%} spam) — {email_text[:70]}...")

print("\n✅ Done!")
